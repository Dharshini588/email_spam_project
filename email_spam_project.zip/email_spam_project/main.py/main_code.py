import pandas as pd
import joblib
import re

data = pd.read_csv("data/spam.csv", encoding="latin-1")
x_data = data["v2"]   
y_data = data["v1"] 


print("First 5 emails:")
print(x_data.head())

print("\nFirst 5 labels:")
print(y_data.head())
print("Label counts in dataset:")
print(y_data.value_counts())

from pathlib import Path

# Load the retrained model and vectorizer (TF-IDF + LogisticRegression)
model_path = Path("spam_model.pkl")
vec_path = Path("vectorizer.pkl")
if model_path.exists() and vec_path.exists():
    model = joblib.load(str(model_path))
    vectorizer = joblib.load(str(vec_path))
    print("Loaded saved model and vectorizer.")
else:
    raise FileNotFoundError("Saved model or vectorizer not found. Run retrain_tfidf_lr.py first.")

print("\n--- Test with your own email ---")
user_email = input("Enter an email message: ")

# Preprocess the user input the same way as training data
clean_email = user_email.lower()
clean_email = re.sub('[^\\w\\s]', '', clean_email)

# Convert text to numbers using the SAME vectorizer
user_email_vector = vectorizer.transform([clean_email])

# Predict spam or ham and show probabilities if available
try:
    probs = model.predict_proba(user_email_vector)[0]
    # map probabilities to classes
    class_prob = dict(zip(model.classes_, probs))
    pred = model.predict(user_email_vector)[0]
    print(f"Prediction: {pred}")
    for c in model.classes_:
        print(f"  prob({c}) = {class_prob.get(c, 0):.4f}")
except Exception:
    # fallback to predict only
    pred = model.predict(user_email_vector)[0]
    print(f"Prediction: {pred}")






